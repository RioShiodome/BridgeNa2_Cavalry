﻿#target aftereffects
// ExtendScript releases without a built-in JSON object. No eval is used.
(function(G){
 if(typeof G.JSON!=='undefined')return;
 function quote(s){return '"'+String(s).replace(/["\\\x00-\x1f]/g,function(c){if(c==='"'||c==='\\')return '\\'+c;return '\\u'+('0000'+c.charCodeAt(0).toString(16)).slice(-4);})+'"';}
 function stringify(v){
  if(v===null)return 'null';var t=typeof v;if(t==='string')return quote(v);if(t==='number')return isFinite(v)?String(v):'null';if(t==='boolean')return String(v);if(t!=='object')return undefined;
  var parts=[],i,k,value;if(v instanceof Array){for(i=0;i<v.length;i++)parts.push(stringify(v[i])||'null');return '['+parts.join(',')+']';}
  for(k in v)if(Object.prototype.hasOwnProperty.call(v,k)){value=stringify(v[k]);if(value!==undefined)parts.push(quote(k)+':'+value);}return '{'+parts.join(',')+'}';
 }
 function parse(text){
  var s=String(text).replace(/^\uFEFF/,''),i=0,depth=0;
  function bad(){throw new SyntaxError('Invalid JSON at '+i);}
  function space(){while(i<s.length&&/\s/.test(s.charAt(i)))i++;}
  function str(){var out='',c;if(s.charAt(i++)!=='"')bad();while(i<s.length){c=s.charAt(i++);if(c==='"')return out;if(c==='\\'){c=s.charAt(i++);if(c==='u'){var h=s.substr(i,4);if(!/^[0-9a-fA-F]{4}$/.test(h))bad();out+=String.fromCharCode(parseInt(h,16));i+=4;}else {var es={'"':'"','\\':'\\','/':'/','b':'\b','f':'\f','n':'\n','r':'\r','t':'\t'};if(!Object.prototype.hasOwnProperty.call(es,c))bad();out+=es[c];}}else{if(c.charCodeAt(0)<32)bad();out+=c;}}bad();}
  function value(){space();if(++depth>128)bad();var c=s.charAt(i),v,key,m;if(c==='"')v=str();else if(c==='{'||c==='['){var array=c==='[';i++;v=array?[]:{};space();if(s.charAt(i)===(array?']':'}'))i++;else{while(true){space();if(array)v.push(value());else{key=str();if(key==='__proto__')bad();space();if(s.charAt(i++)!==':')bad();v[key]=value();}space();c=s.charAt(i++);if(c===(array?']':'}'))break;if(c!==',')bad();}}}else if(s.substr(i,4)==='true'){v=true;i+=4;}else if(s.substr(i,5)==='false'){v=false;i+=5;}else if(s.substr(i,4)==='null'){v=null;i+=4;}else {m=/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(s.substr(i));if(!m)bad();v=Number(m[0]);if(!isFinite(v))bad();i+=m[0].length;}depth--;return v;}
  var v=value();space();if(i!==s.length)bad();return v;
 }
 G.JSON={parse:parse,stringify:stringify};
})($.global);

// Native panels receive the exact native root. Standalone scripts guard getenv:
// host APIs can be unavailable/throw, and ~ can follow a different custom HOME.
(function(G){
    function absolute(path){return /^[a-z]:\//i.test(path)||/^\/\/[^\/]+\/[^\/]+(?:\/|$)/.test(path);}
    function normalize(path){return typeof path==='string'?path.replace(/\\/g,'/').replace(/\/+$/,''):'';}
    G.BN_CacheRoot=function(channel){
        var base='',home='',data='',value='';
        if(typeof $.os==='string'&&/windows/i.test($.os)){
            base=normalize(G.BN_NativeCacheRoot);
            if(!absolute(base)){
                // Call directly inside try: some ExtendScript host methods do
                // not report typeof === 'function'. Never call a missing API.
                try{if($.getenv)value=$.getenv('USERPROFILE');}catch(_){}
                home=normalize(value);
                if(!absolute(home)){
                    // Only the standard AppData layout identifies a profile.
                    // Redirected folders must use the native effect's picker.
                    try{data=normalize(Folder.userData.fsName);}catch(_){}
                    var m=/^(.*)\/AppData\/Roaming$/i.exec(data);
                    home=m&&absolute(m[1])?m[1]:'';
                }
                if(!home)throw Error('BridgeNa2 4.6.4 无法读取 Windows 用户目录。请先给图层添加 BridgeNa2_Cavalry 效果，并从效果中点击 Choose composition；新版原生插件会直接提供缓存路径。');
                base=home+'/Cavalry AE Native/default';
            }
        }else base='~/Cavalry AE Native/default';
        return Folder(base+(channel?'/channels/'+channel:''));
    };
})($.global);

// Read selected BridgeNa2 effect parameters. Does not change the AE project.
(function(){
 try{
  var c=app.project&&app.project.activeItem;
  if(!(c instanceof CompItem)){alert('请打开黑画面所在的合成，并选中 BridgeNa2 图层。');return;}
  var layers=c.selectedLayers;if(!layers.length){alert('请先选中出现黑画面的 BridgeNa2 图层。');return;}
  var report={tool:'BridgeNa2 preview diagnostic 1',ae:app.version,os:$.os,bitsPerChannel:app.project.bitsPerChannel,workingSpace:app.project.workingSpace,comp:{name:c.name,time:c.time,width:c.width,height:c.height,frameRate:c.frameRate},layers:[]};
  var fields={2:'live',3:'duration',4:'quality',5:'cachedPercent',6:'revision',7:'offset',10:'customRange',11:'first',12:'last',13:'transparent',14:'channel'};
  for(var i=0;i<layers.length;i++){
   var l=layers[i],es=l.property('ADBE Effect Parade'),effects=[];
   for(var j=1;j<=es.numProperties;j++){
    var e=es.property(j);if(e.matchName!=='Cavalry Native Preview')continue;
    var data={enabled:e.enabled,name:e.name};for(var k in fields)if(Number(k)<=e.numProperties)data[fields[k]]=e.property(Number(k)).value;
    var v=Number(data.channel),n=Number(data.revision);
    if(v>0&&v<=2000000001&&Math.floor(v)===v&&n>0&&n<=2000000001&&Math.floor(n)===n){
     try{
      var root=$.global.BN_CacheRoot(v);var snapshot=File(root.fsName+'/snapshots/'+n+'.txt');
      data.cacheRoot=root.fsName;data.snapshotExists=snapshot.exists;
      if(snapshot.exists){snapshot.encoding='UTF-8';if(snapshot.open('r')){data.snapshotText=snapshot.read(12000);snapshot.close();}}
     }catch(pathError){data.pathError=String(pathError);}
    }
    effects.push(data);
   }
   if(effects.length)report.layers.push({name:l.name,id:l.id,enabled:l.enabled,locked:l.locked,solo:l.solo,startTime:l.startTime,inPoint:l.inPoint,outPoint:l.outPoint,stretch:l.stretch,effects:effects});
  }
  if(!report.layers.length){alert('选中图层上没有 BridgeNa2_Cavalry 效果。');return;}
  var output=File.saveDialog('保存黑画面诊断报告（不修改工程）');if(!output)return;
  if(!/\.json$/i.test(output.name))output=File(output.fsName+'.json');output.encoding='UTF-8';
  if(!output.open('w'))throw Error('无法写入报告');output.write(JSON.stringify(report));output.close();
  alert('已保存诊断报告：\n'+output.fsName+'\n报告含合成、图层名称和本机缓存路径。');
 }catch(e){alert('诊断报告失败：'+String(e));}
})();
