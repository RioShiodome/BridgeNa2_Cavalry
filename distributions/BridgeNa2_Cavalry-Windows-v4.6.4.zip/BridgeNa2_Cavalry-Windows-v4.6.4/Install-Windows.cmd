@echo off
call "%~dp0install\Install-Windows.cmd"
