#!/bin/zsh
set -eu
TASK_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
exec "$TASK_DIR/install/Install-Mac.command"
